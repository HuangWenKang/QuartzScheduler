﻿using System;
using System.Linq;
using FluentAssert;
using NUnit.Framework;
using OrderLoadService.WorkFlowRule;
using System.IO;

namespace OrderLoadService.Test
{
    public class RuleItemParserServiceTest
    {
        private IParserService<RuleItem> parserService = new RuleItemParserService();

        [Test]
        public void ParseOrderItemsTest()
        {
            string file = Path.Combine(AppDomain.CurrentDomain.BaseDirectory,@"Data\Rules.csv");
            var items = parserService.ParseFromCsv(file);
            items.ShouldNotBeNull();
            items.Count().ShouldBeGreaterThan(0);

        }
    }
}
