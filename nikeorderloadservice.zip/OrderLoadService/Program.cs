﻿
using Ninject;
using System;
using Topshelf;
using Topshelf.HostConfigurators;
using OrderLoadService.WorkFlowRule;

namespace OrderLoadService
{
    class Program
    {
        private static IKernel Container;
        static void Main(string[] args)
        {
           
            HostFactory.Run(ConfigureCallback);
        }

        private static void ConfigureCallback(HostConfigurator serviceConfig)
        {            
            serviceConfig.UseNLog();

            

            serviceConfig.RunAsLocalSystem();
           
            serviceConfig.SetServiceName("NikeOrderLoader");
            serviceConfig.SetDisplayName("Nike Orders Loaderer");
            serviceConfig.SetDescription("Nike Order Import Service");

            serviceConfig.StartAutomatically();
        }
        
       
    }
}
