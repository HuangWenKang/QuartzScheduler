﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace OrderLoadService.WorkFlowRule
{
    public class RuleItem
    {

        public string Id { get; set; }
        public List<string> CurrentWorkFlowStatus { get; set; }
        public List<string> RequestStatus { get; set; }

        public List<string> SelectedOptions { get; set; }

        public string NewOrExisting { get; set; }

        public string DoneParallelOption { get; set; }

        public List<string> NextWorkFlowStatus { get; set; }

        public List<string> NextActions { get; set; }
    }
}