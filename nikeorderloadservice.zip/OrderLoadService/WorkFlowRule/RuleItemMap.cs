﻿using CsvHelper.Configuration;

namespace OrderLoadService.WorkFlowRule
{
    public sealed class RuleItemMap : ClassMap<RuleItem>
    {
        public RuleItemMap()
        {
            AutoMap();

            Map(m => m.CurrentWorkFlowStatus).Name("Key_CurrentWorkFlowStatus").TypeConverter<ListTypeConverter>();
            Map(m => m.RequestStatus).Name("Key_RequestStatus").TypeConverter<ListTypeConverter>();
            Map(m => m.SelectedOptions).Name("Key_SelectedOptions").TypeConverter<ListTypeConverter>();
            Map(m => m.NewOrExisting).Name("Key_NewOrExisting");
            Map(m => m.DoneParallelOption).Name("Key_DoneParallelOption");

            Map(m => m.NextWorkFlowStatus).Name("NextWorkFlowStatus").TypeConverter<ListTypeConverter>();
            Map(m => m.NextActions).Name("NextActions").TypeConverter<ListTypeConverter>();


        }
    }
}
