﻿using CsvHelper;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace OrderLoadService.WorkFlowRule
{
    public class RuleItemParserService : IParserService<RuleItem>
    {
        public IEnumerable<RuleItem> ParseFromCsv(string file)
        {
            using (var sr = new StreamReader(file))
            {
                using (var reader = new CsvReader(sr))
                {
                    reader.Configuration.RegisterClassMap<RuleItemMap>();

                    var ruleItems = reader.GetRecords<RuleItem>();

                    return ruleItems.ToList();
                }
            }
        }
    }
}
