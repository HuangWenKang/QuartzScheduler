﻿using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using System;
using System.Collections.Generic;

namespace OrderLoadService.WorkFlowRule
{
    class ListTypeConverter : ITypeConverter
    {
        public static readonly string Seperator = @",";
        public object ConvertFromString(string text, IReaderRow row, MemberMapData memberMapData)
        {
            if (string.IsNullOrWhiteSpace(text)) { return new List<string> { }; }

            var items = text.Split(new string[] { ",", "&", "|" }, StringSplitOptions.RemoveEmptyEntries);

            return new List<string>(items);
        }

        public string ConvertToString(object value, IWriterRow row, MemberMapData memberMapData)
        {
            throw new NotImplementedException();
        }
    }
}
