﻿using System.Collections.Generic;

namespace OrderLoadService.WorkFlowRule
{
    public interface IParserService<T>
    {
        IEnumerable<T> ParseFromCsv(string csvFile);
    }
}