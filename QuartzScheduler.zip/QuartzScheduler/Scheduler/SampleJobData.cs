﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuartzScheduler.Scheduler
{
    public class SampleJobData
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}