﻿using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuartzScheduler.Scheduler
{
    public static class JobSchedulerConfig
    {
        public static IScheduler scheduler;

        static JobSchedulerConfig()
        {
            scheduler = StdSchedulerFactory.GetDefaultScheduler();
            scheduler.Start();
        }

        public static void TriggerAllServiceNotification() 
        {
            var jobData = new SampleJobData { Name = "Gary", Value = "Huang" };
            var jobDataMap = new JobDataMap();
            jobDataMap.Add("jobData", jobData);

            IJobDetail job = JobBuilder.Create<EmailJob>().WithIdentity("job1", "group1").UsingJobData(jobDataMap).Build();


            ITrigger trigger = TriggerBuilder.Create()
                                            .WithIdentity("trigger3", "group1")
                                            .WithCronSchedule("0/10 * * * * ?")
                                            .ForJob("job1", "group1")
                                            .Build();

            scheduler.ScheduleJob(job, trigger);
        }
    }
}