﻿using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace QuartzScheduler.Scheduler
{
    public class EmailJob : IJob
    {
        public void Execute(IJobExecutionContext context)
        {

            try
            {
                var jobDataMap = context.JobDetail.JobDataMap;
                var sampleData = jobDataMap.Get("jobData") as SampleJobData;
                if (sampleData != null)
                {
                    Console.Out.WriteLine($"Get Job Data: {sampleData.Name} {sampleData.Value}");
                }
                using (var message = new MailMessage("user@gmail.com", "user@live.co.uk"))
                {
                    message.Subject = "Test";
                    message.Body = "Test at " + DateTime.Now;
                    using (SmtpClient client = new SmtpClient
                    {
                        EnableSsl = true,
                        Host = "smtp.gmail.com",
                        Port = 587,
                        Credentials = new NetworkCredential("user@gmail.com", "password")
                    })
                    {
                        client.Send(message);
                    }
                }
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.Message);
            }
           
        }
    }
}